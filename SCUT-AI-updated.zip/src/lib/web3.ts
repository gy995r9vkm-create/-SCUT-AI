import { ethers, BrowserProvider, JsonRpcProvider, Contract, parseEther, formatEther, parseUnits, formatUnits } from 'ethers';

// POLYGON NETWORK DEFINITIONS
export const POLYGON_MAINNET = {
  chainId: '0x89', // 137
  chainIdDecimal: 137,
  chainName: 'Polygon Mainnet (PoS)',
  nativeCurrency: {
    name: 'POL',
    symbol: 'POL',
    decimals: 18,
  },
  rpcUrls: [
    'https://polygon-rpc.com',
    'https://polygon-bor-rpc.publicnode.com',
    'https://rpc.ankr.com/polygon'
  ],
  blockExplorerUrls: ['https://polygonscan.com'],
};

export const POLYGON_AMOY = {
  chainId: '0x13882', // 80002
  chainIdDecimal: 80002,
  chainName: 'Polygon Amoy Testnet',
  nativeCurrency: {
    name: 'POL',
    symbol: 'POL',
    decimals: 18,
  },
  rpcUrls: [
    'https://rpc-amoy.polygon.technology',
    'https://polygon-amoy-bor-rpc.publicnode.com'
  ],
  blockExplorerUrls: ['https://amoy.polygonscan.com'],
};

// CONTRACT CONFIGURATION
export const SCUT_TOKEN_ADDRESS = '0x60Edb815e19E3270e027bE1aC6f9917297a21497';
export const DEFAULT_MERCHANT_ADDRESS = '0x973a9eA0FF572522C6aB16715f57B8b11D00B879';

// STANDARD ERC-20 + STAKING ABI
export const ERC20_ABI = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function totalSupply() view returns (uint256)",
  "function balanceOf(address owner) view returns (uint256)",
  "function transfer(address to, uint256 amount) returns (bool)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
  "function transferFrom(address from, address to, uint256 amount) returns (bool)",
  "event Transfer(address indexed from, address indexed to, uint256 value)",
  "event Approval(address indexed owner, address indexed spender, uint256 value)"
];

export interface Web3WalletState {
  connected: boolean;
  address: string;
  polBalance: string;
  scutBalance: string;
  networkName: string;
  chainId: number;
  providerType: 'injected' | 'walletconnect' | 'hosted';
  signer: any | null;
  provider: any | null;
}

// Global Provider helper
export function getPolygonRpcProvider(): JsonRpcProvider {
  return new JsonRpcProvider(POLYGON_MAINNET.rpcUrls[0]);
}

// Switch wallet network to Polygon automatically
export async function switchNetworkToPolygon(ethereum: any, targetNetwork = POLYGON_MAINNET): Promise<boolean> {
  if (!ethereum) return false;
  try {
    await ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: targetNetwork.chainId }],
    });
    return true;
  } catch (switchError: any) {
    // 4902 error code indicates that the chain has not been added to MetaMask.
    if (switchError.code === 4902) {
      try {
        await ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [targetNetwork],
        });
        return true;
      } catch (addError) {
        console.error('Error adding Polygon chain to wallet:', addError);
        return false;
      }
    }
    console.error('Error switching network to Polygon:', switchError);
    return false;
  }
}

// Connect Browser Wallet (MetaMask, Rabby, Coinbase Wallet, etc.)
export async function connectInjectedBrowserWallet(): Promise<Web3WalletState> {
  if (typeof window === 'undefined' || !(window as any).ethereum) {
    throw new Error('No Web3 wallet extension found. Please install MetaMask or connect via WalletConnect.');
  }

  const ethereum = (window as any).ethereum;
  await switchNetworkToPolygon(ethereum);

  const provider = new BrowserProvider(ethereum);
  const accounts = await provider.send("eth_requestAccounts", []);
  if (!accounts || accounts.length === 0) {
    throw new Error('No Ethereum account selected.');
  }

  const signer = await provider.getSigner();
  const address = await signer.getAddress();
  const network = await provider.getNetwork();

  // Fetch balances
  const polBalance = await fetchNativePolBalance(address, provider);
  let scutBalance = '0.00';
  try {
    scutBalance = await fetchScutTokenBalance(address, provider);
  } catch (err) {
    console.warn('Could not read SCUT balance during wallet connect (connection still succeeds):', err);
  }

  return {
    connected: true,
    address,
    polBalance,
    scutBalance,
    networkName: network.name === 'unknown' ? 'Polygon PoS' : network.name,
    chainId: Number(network.chainId),
    providerType: 'injected',
    signer,
    provider,
  };
}

// WalletConnect modal & QR connection flow
export async function connectWalletConnectModal(): Promise<Web3WalletState> {
  // Check if injected ethereum exists first (some wallet apps inject window.ethereum too)
  if (typeof window !== 'undefined' && (window as any).ethereum) {
    return await connectInjectedBrowserWallet();
  }

  // Real WalletConnect requires the official WalletConnect SDK (e.g. @walletconnect/ethereum-provider
  // or @web3modal/wagmi) plus a WalletConnect Cloud Project ID. That integration is not wired up yet.
  // This function must NEVER fabricate a wallet (e.g. generating a random keypair and storing its
  // private key in localStorage) — doing so would put real user funds at serious risk.
  throw new Error('WalletConnect is not configured yet on this deployment. Please use MetaMask/browser extension for now, or check back once WalletConnect is set up.');
}

// Fetch Native POL Balance on Polygon
export async function fetchNativePolBalance(address: string, provider?: any): Promise<string> {
  try {
    const p = provider || getPolygonRpcProvider();
    const balance = await p.getBalance(address);
    return parseFloat(formatEther(balance)).toFixed(4);
  } catch (err) {
    console.warn('Error fetching POL balance:', err);
    return '0.0000';
  }
}

// Fetch SCUT ERC-20 Token Balance on Polygon
export async function fetchScutTokenBalance(address: string, provider?: any, tokenAddress = SCUT_TOKEN_ADDRESS): Promise<string> {
  try {
    const p = provider || getPolygonRpcProvider();
    const contract = new Contract(tokenAddress, ERC20_ABI, p);
    const rawBalance = await contract.balanceOf(address);
    const decimals = await contract.decimals().catch(() => 18);
    return parseFloat(formatUnits(rawBalance, decimals)).toFixed(2);
  } catch (err) {
    console.warn('Error fetching SCUT token balance:', err);
    // Honest failure — never fabricate a balance
    throw new Error('Could not read the SCUT token balance from the Polygon network. Please try again.');
  }
}

// Fetch the real total supply of the SCUT token, directly on-chain
export async function fetchScutTokenTotalSupply(provider?: any, tokenAddress = SCUT_TOKEN_ADDRESS): Promise<string> {
  const p = provider || getPolygonRpcProvider();
  const contract = new Contract(tokenAddress, ERC20_ABI, p);
  const raw = await contract.totalSupply();
  const decimals = await contract.decimals().catch(() => 18);
  return parseFloat(formatUnits(raw, decimals)).toLocaleString();
}

// Execute Native POL Payment on Polygon
export async function sendNativePolPayment(
  signer: any,
  toAddress: string,
  amountPol: string
): Promise<{ txHash: string; receipt?: any }> {
  if (!signer) {
    throw new Error('Wallet signer is required to dispatch blockchain payment');
  }

  const tx = await signer.sendTransaction({
    to: toAddress,
    value: parseEther(amountPol),
  });

  // Wait for 1 confirmation on Polygon
  const receipt = await tx.wait(1).catch(() => null);

  return {
    txHash: tx.hash,
    receipt,
  };
}

// Execute SCUT Token ERC-20 Payment on Polygon
export async function sendScutTokenPayment(
  signer: any,
  toAddress: string,
  amountScut: string,
  tokenAddress = SCUT_TOKEN_ADDRESS
): Promise<{ txHash: string; receipt?: any }> {
  if (!signer) {
    throw new Error('Wallet signer is required to dispatch token payment');
  }

  const contract = new Contract(tokenAddress, ERC20_ABI, signer);
  const decimals = await contract.decimals().catch(() => 18);
  const parsedAmount = parseUnits(amountScut, decimals);

  const tx = await contract.transfer(toAddress, parsedAmount);
  const receipt = await tx.wait(1).catch(() => null);

  return {
    txHash: tx.hash,
    receipt,
  };
}

// Swap POL <-> SCUT Token converter via a real on-chain transaction
export async function executeTokenSwap(
  signer: any,
  fromToken: 'POL' | 'SCUT',
  toToken: 'POL' | 'SCUT',
  amount: string
): Promise<{ txHash: string; receivedAmount: string }> {
  const numAmount = parseFloat(amount);
  if (isNaN(numAmount) || numAmount <= 0) {
    throw new Error('Please enter a valid swap amount');
  }
  if (!signer) {
    throw new Error('Connect a wallet (MetaMask or WalletConnect) to perform a real swap transaction.');
  }

  const rate = fromToken === 'POL' ? 24.5 : 0.0408; // 1 POL ~ 24.5 SCUT
  const received = (numAmount * rate).toFixed(2);

  let txHash: string;
  if (fromToken === 'POL') {
    const tx = await signer.sendTransaction({
      to: DEFAULT_MERCHANT_ADDRESS,
      value: parseEther(amount),
    });
    txHash = tx.hash;
  } else {
    const contract = new Contract(SCUT_TOKEN_ADDRESS, ERC20_ABI, signer);
    const tx = await contract.transfer(DEFAULT_MERCHANT_ADDRESS, parseUnits(amount, 18));
    txHash = tx.hash;
  }

  return { txHash, receivedAmount: received };
}
