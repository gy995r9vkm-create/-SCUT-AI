/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Users, CreditCard, Ticket, BarChart3, ShieldAlert, Cpu, 
  Wallet, Layers, Search, RefreshCw, Trash2, CheckCircle, 
  ArrowUpRight, AlertTriangle, Coins, Lock, Mail, ExternalLink, Flame
} from 'lucide-react';
import { getAllUsers, getAllSupportTickets, adminUpdateUser, adminDeleteSupportTicket } from '../lib/db';
import { User, SubscriptionTier } from '../types';
import { adjustCredits } from '../lib/credits';
import { getPolygonRpcProvider, fetchScutTokenBalance, SCUT_TOKEN_ADDRESS, DEFAULT_MERCHANT_ADDRESS } from '../lib/web3';
import { formatUnits } from 'ethers';

interface AdminDashboardProps {
  adminEmail: string;
}

export default function AdminDashboard({ adminEmail }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'approvals' | 'users' | 'subscriptions' | 'tickets' | 'analytics' | 'wallets' | 'security' | 'credits'>('approvals');
  const [users, setUsers] = useState<any[]>([]);
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [systemAlerts, setSystemAlerts] = useState<string[]>([]);
  const [selectedUser, setSelectedUser] = useState<any | null>(null);

  // Reject Modal State
  const [rejectModalUser, setRejectModalUser] = useState<any | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState('');
  const [actionProcessing, setActionProcessing] = useState(false);

  // Live Polygon on-chain telemetry (real RPC reads — null until fetched)
  const [polygonGasPrice, setPolygonGasPrice] = useState<string | null>(null);
  const [treasuryBalance, setTreasuryBalance] = useState<string | null>(null);
  const [chainDataLoading, setChainDataLoading] = useState(false);
  const [chainDataError, setChainDataError] = useState(false);

  const refreshChainData = async () => {
    setChainDataLoading(true);
    setChainDataError(false);
    try {
      const provider = getPolygonRpcProvider();
      const [feeData, balance] = await Promise.all([
        provider.getFeeData(),
        fetchScutTokenBalance(DEFAULT_MERCHANT_ADDRESS, provider),
      ]);
      const gwei = feeData.gasPrice ? formatUnits(feeData.gasPrice, 'gwei') : null;
      setPolygonGasPrice(gwei ? `${parseFloat(gwei).toFixed(2)} Gwei` : null);
      setTreasuryBalance(balance ? `${Number(balance).toLocaleString()} SCUT` : null);
      setSystemAlerts(prev => ["Refreshed live Polygon gas price and treasury balance from on-chain RPC.", ...prev]);
    } catch (err) {
      console.warn('Error fetching Polygon telemetry:', err);
      setChainDataError(true);
    } finally {
      setChainDataLoading(false);
    }
  };

  const refreshData = async () => {
    setLoading(true);
    try {
      const allUsers = await getAllUsers();
      const allTickets = await getAllSupportTickets();

      // Real data only — elevate the known admin accounts, but never fabricate users.
      const mapped = allUsers.map(u => {
        if (['gabrielicloudi@icloud.com'].includes((u.email || '').toLowerCase())) {
          return { ...u, isAdmin: true, approvalStatus: 'approved', isApproved: true };
        }
        return u;
      });
      setUsers(mapped);
      setTickets(allTickets);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
    refreshChainData();
  }, []);

  const handleUpdateTier = async (uid: string, newTier: SubscriptionTier) => {
    try {
      const maxLimits = { free: 100, pro: 1000000, business: 10000000, enterprise: 999999999 };
      const updatedFields = {
        subscriptionTier: newTier,
        maxUsage: maxLimits[newTier]
      };
      
      // Update local state
      setUsers(prev => prev.map(u => u.id === uid ? { ...u, ...updatedFields } : u));
      if (selectedUser && selectedUser.id === uid) {
        setSelectedUser((prev: any) => ({ ...prev, ...updatedFields }));
      }

      await adminUpdateUser(uid, updatedFields);
      setSystemAlerts(prev => [`User [${uid}] updated to subscription tier ${newTier.toUpperCase()}`, ...prev]);
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleAdmin = async (uid: string, currentIsAdmin: boolean) => {
    try {
      const updatedFields = { isAdmin: !currentIsAdmin };
      setUsers(prev => prev.map(u => u.id === uid ? { ...u, ...updatedFields } : u));
      if (selectedUser && selectedUser.id === uid) {
        setSelectedUser((prev: any) => ({ ...prev, ...updatedFields }));
      }
      await adminUpdateUser(uid, updatedFields);
      setSystemAlerts(prev => [`Admin privileges toggled for User [${uid}]`, ...prev]);
    } catch (err) {
      console.error(err);
    }
  };

  const handleApproveUser = async (userToApprove: any) => {
    setActionProcessing(true);
    try {
      const uid = userToApprove.id || `user-${userToApprove.email.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
      const updatedFields = {
        approvalStatus: 'approved' as const,
        isApproved: true,
        rejectionReason: ''
      };

      // Update in DB / Firestore
      await adminUpdateUser(uid, updatedFields);

      // Send automated approval email to user
      await fetch('/api/auth/approve-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: userToApprove.name,
          email: userToApprove.email,
          selectedCommunity: userToApprove.selectedCommunity
        })
      });

      // Update local state
      setUsers(prev => prev.map(u => (u.id === uid || u.email === userToApprove.email) ? { ...u, ...updatedFields } : u));
      
      setSystemAlerts(prev => [
        `[APPROVAL AUDIT] ${new Date().toLocaleTimeString()} — Approved user ${userToApprove.name} (${userToApprove.email}) for ${userToApprove.selectedCommunity === 'women_girls' ? 'SCUT Women & Girls' : 'SCUT Men & Boys'}. Approval email dispatched to user.`,
        ...prev
      ]);
    } catch (err: any) {
      console.error('Failed to approve user:', err);
    } finally {
      setActionProcessing(false);
    }
  };

  const handleRejectUser = async () => {
    if (!rejectModalUser) return;
    setActionProcessing(true);
    try {
      const userToReject = rejectModalUser;
      const uid = userToReject.id || `user-${userToReject.email.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
      const reason = rejectionReasonInput.trim() || 'Does not meet membership eligibility criteria for this circle.';
      
      const updatedFields = {
        approvalStatus: 'rejected' as const,
        isApproved: false,
        rejectionReason: reason
      };

      // Update in DB / Firestore
      await adminUpdateUser(uid, updatedFields);

      // Send automated rejection email to user
      await fetch('/api/auth/reject-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: userToReject.name,
          email: userToReject.email,
          selectedCommunity: userToReject.selectedCommunity,
          reason
        })
      });

      // Update local state
      setUsers(prev => prev.map(u => (u.id === uid || u.email === userToReject.email) ? { ...u, ...updatedFields } : u));
      
      setSystemAlerts(prev => [
        `[REJECTION AUDIT] ${new Date().toLocaleTimeString()} — Rejected user ${userToReject.name} (${userToReject.email}). Reason: "${reason}". Rejection email dispatched.`,
        ...prev
      ]);

      setRejectModalUser(null);
      setRejectionReasonInput('');
    } catch (err: any) {
      console.error('Failed to reject user:', err);
    } finally {
      setActionProcessing(false);
    }
  };

  const handleDeleteTicket = async (id: string) => {
    try {
      setTickets(prev => prev.filter(t => t.id !== id));
      await adminDeleteSupportTicket(id);
      setSystemAlerts(prev => [`Support Ticket Resolved & Purged from index: ${id}`, ...prev]);
    } catch (err) {
      console.error(err);
    }
  };

  const filteredUsers = users.filter(u => 
    u.email?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.walletAddress?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-950 text-white pt-24 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header Title with Branding */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-900 pb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold tracking-widest uppercase bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                SCUT ECOSYSTEM SYSTEM CONTROL
              </span>
            </div>
            <h1 className="font-display text-3xl font-extrabold tracking-tight text-gradient">
              Administrative Console
            </h1>
            <p className="text-slate-400 text-xs mt-1">
              Active Session: <span className="font-semibold text-cyan-400">{adminEmail}</span> (Administrator)
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={refreshData}
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-xs font-bold transition-all text-slate-300 flex items-center gap-2"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              Telemetry Sync
            </button>
            <a
              href="https://scutpay.com"
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/15 border border-cyan-500/25 text-xs font-bold transition-all text-cyan-400 flex items-center gap-1.5"
            >
              <span>scutpay.com</span>
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>

        {/* Dashboard Stat Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl glass-panel border border-slate-900/60 relative overflow-hidden">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 w-fit mb-3">
              <Users className="h-5 w-5" />
            </div>
            <span className="text-[10px] text-slate-500 font-semibold block uppercase tracking-wider">Total Registered Profiles</span>
            <span className="text-2xl font-bold block mt-1">{users.length}</span>
            <span className="text-[10px] text-emerald-400 font-semibold block mt-1">✔ 100% cloud synced</span>
          </div>

          <div className="p-5 rounded-2xl glass-panel border border-slate-900/60 relative overflow-hidden">
            <div className="p-2 rounded-xl bg-teal-500/10 text-teal-400 w-fit mb-3">
              <CreditCard className="h-5 w-5" />
            </div>
            <span className="text-[10px] text-slate-500 font-semibold block uppercase tracking-wider">Paying Subscribers</span>
            <span className="text-2xl font-bold block mt-1">{users.filter(u => u.subscriptionTier && u.subscriptionTier !== 'free').length}</span>
            <span className="text-[10px] text-slate-500 block mt-1">From real account records — billing ledger not yet connected</span>
          </div>

          <div className="p-5 rounded-2xl glass-panel border border-slate-900/60 relative overflow-hidden">
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 w-fit mb-3">
              <Ticket className="h-5 w-5" />
            </div>
            <span className="text-[10px] text-slate-500 font-semibold block uppercase tracking-wider">Open Support Tickets</span>
            <span className="text-2xl font-bold block mt-1 text-purple-400">{tickets.length}</span>
            <span className="text-[10px] text-slate-500 font-semibold block mt-1">{tickets.length > 0 ? '▲ Review needed' : 'Queue clear'}</span>
          </div>

          <div className="p-5 rounded-2xl glass-panel border border-slate-900/60 relative overflow-hidden">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 w-fit mb-3">
              <Coins className="h-5 w-5" />
            </div>
            <span className="text-[10px] text-slate-500 font-semibold block uppercase tracking-wider">SCUT Polygon Token</span>
            <span className="text-2xl font-bold block mt-1">{SCUT_TOKEN_ADDRESS.substring(0, 6)}...{SCUT_TOKEN_ADDRESS.slice(-4)}</span>
            <span className="text-[10px] text-slate-400 block mt-1">Polygon mainnet ERC-20</span>
          </div>
        </div>

        {/* System Logs / Alerts ticker — populated only by real admin actions in this session */}
        <div className="p-4 rounded-xl bg-slate-900/30 border border-slate-900 flex items-start gap-3">
          <ShieldAlert className="h-5 w-5 text-cyan-400 mt-0.5 shrink-0" />
          <div className="space-y-1 w-full text-xs">
            <span className="font-bold text-slate-300 block">Recent Admin Activity:</span>
            {systemAlerts.length === 0 ? (
              <p className="text-slate-600">No admin actions taken yet this session.</p>
            ) : (
              <div className="grid md:grid-cols-3 gap-2">
                {systemAlerts.slice(0, 3).map((al, idx) => (
                  <div key={idx} className="flex gap-1.5 items-center text-slate-500">
                    <div className="h-1.5 w-1.5 rounded-full bg-cyan-400 shrink-0" />
                    <span className="truncate">{al}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Main Tabbed Grid */}
        <div className="grid lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Navigation Rails */}
          <div className="lg:col-span-3 space-y-1.5">
            <span className="text-[10px] text-slate-500 font-semibold block px-3 uppercase tracking-wider mb-2">Management Realms</span>
            
            <button
              onClick={() => setActiveTab('approvals')}
              className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center justify-between ${
                activeTab === 'approvals' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <span className="flex items-center gap-3">
                <ShieldAlert className="h-4 w-4 text-amber-400" />
                Community Approvals
              </span>
              {users.filter(u => u.approvalStatus === 'pending_approval' || (u.isApproved === false && u.selectedCommunity && u.selectedCommunity !== 'none')).length > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950 leading-none">
                  {users.filter(u => u.approvalStatus === 'pending_approval' || (u.isApproved === false && u.selectedCommunity && u.selectedCommunity !== 'none')).length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-3 ${activeTab === 'users' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-900'}`}
            >
              <Users className="h-4 w-4" />
              Users Database
            </button>

            <button
              onClick={() => setActiveTab('subscriptions')}
              className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-3 ${activeTab === 'subscriptions' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-900'}`}
            >
              <CreditCard className="h-4 w-4" />
              Subscriptions & Billing
            </button>

            <button
              onClick={() => setActiveTab('tickets')}
              className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center justify-between ${activeTab === 'tickets' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-900'}`}
            >
              <span className="flex items-center gap-3">
                <Ticket className="h-4 w-4" />
                Support Ticket Queue
              </span>
              {tickets.length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950 leading-none">
                  {tickets.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-3 ${activeTab === 'analytics' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-900'}`}
            >
              <BarChart3 className="h-4 w-4" />
              Ecosystem Analytics
            </button>

            <button
              onClick={() => setActiveTab('wallets')}
              className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-3 ${activeTab === 'wallets' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-900'}`}
            >
              <Wallet className="h-4 w-4" />
              Polygon SCUT Wallets
            </button>

            <button
              onClick={() => setActiveTab('security')}
              className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-3 ${activeTab === 'security' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-900'}`}
            >
              <ShieldAlert className="h-4 w-4" />
              System Security Logs
            </button>

            <button
              onClick={() => setActiveTab('credits')}
              className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-3 ${activeTab === 'credits' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-900'}`}
            >
              <Coins className="h-4 w-4" />
              SCUT Credits Manager
            </button>
          </div>

          {/* Right Work Content */}
          <div className="lg:col-span-9 glass-panel border border-slate-900 rounded-2xl overflow-hidden p-6 min-h-[500px]">
            
            {/* TAB: APPROVALS */}
            {activeTab === 'approvals' && (
              <div className="space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <h3 className="font-display font-bold text-lg text-amber-400 flex items-center gap-2">
                      <ShieldAlert className="h-5 w-5" />
                      Community Account Approvals
                    </h3>
                    <p className="text-xs text-slate-400">
                      Review and authorize membership applications for SCUT Women & Girls and SCUT Men & Boys.
                    </p>
                  </div>
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                    <input
                      type="text"
                      placeholder="Search pending applicants..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full rounded-xl bg-slate-900/60 border border-slate-800 pl-10 pr-4 py-2 text-xs focus:outline-none focus:border-amber-500 transition-all text-white"
                    />
                  </div>
                </div>

                {users.filter(u => u.approvalStatus === 'pending_approval' || (u.isApproved === false && u.selectedCommunity && u.selectedCommunity !== 'none')).length === 0 ? (
                  <div className="py-16 text-center text-slate-500 space-y-3 bg-slate-900/20 rounded-2xl border border-slate-900">
                    <CheckCircle className="h-12 w-12 text-emerald-400 mx-auto" />
                    <p className="font-bold text-slate-300">All Account Requests Up To Date</p>
                    <p className="text-xs max-w-md mx-auto text-slate-500">
                      There are currently no pending registration requests awaiting approval. When users register for SCUT Women & Girls or SCUT Men & Boys, their requests will appear here for administrator authorization.
                    </p>
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {users
                      .filter(u => u.approvalStatus === 'pending_approval' || (u.isApproved === false && u.selectedCommunity && u.selectedCommunity !== 'none'))
                      .filter(u => 
                        !searchTerm || 
                        u.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                        u.email?.toLowerCase().includes(searchTerm.toLowerCase())
                      )
                      .map((u) => {
                        const isWomenCircle = u.selectedCommunity === 'women_girls' || u.sex === 'female';
                        return (
                          <div key={u.id || u.email} className="p-5 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-slate-700 transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                            <div className="space-y-2">
                              <div className="flex items-center gap-3 flex-wrap">
                                <span className="font-bold text-white text-base">{u.name}</span>
                                <span className="text-xs font-mono text-slate-400">({u.email})</span>
                                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase border ${
                                  isWomenCircle 
                                    ? 'bg-rose-500/10 text-rose-400 border-rose-500/30' 
                                    : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                                }`}>
                                  {isWomenCircle ? 'SCUT Women & Girls' : 'SCUT Men & Boys'}
                                </span>
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 uppercase">
                                  {u.sex ? `Sex: ${u.sex}` : 'Sex: Not Specified'}
                                </span>
                              </div>
                              <div className="flex items-center gap-4 text-xs text-slate-500 font-mono">
                                <span>Registered: {u.createdAt || 'Recent'}</span>
                                <span>• Status: Pending Administrator Approval</span>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                onClick={() => handleApproveUser(u)}
                                disabled={actionProcessing}
                                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 disabled:opacity-50"
                              >
                                <CheckCircle className="h-4 w-4" />
                                Approve
                              </button>
                              <button
                                onClick={() => setRejectModalUser(u)}
                                disabled={actionProcessing}
                                className="px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold text-xs transition-all flex items-center gap-1.5 disabled:opacity-50"
                              >
                                <Trash2 className="h-4 w-4" />
                                Reject
                              </button>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            )}
            
            {/* TAB: USERS */}
            {activeTab === 'users' && (
              <div className="space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <h3 className="font-display font-bold text-lg">Profiles Directory</h3>
                    <p className="text-xs text-slate-500">Query and update SCUT AI registered accounts, plans, and wallet parameters.</p>
                  </div>
                  <div className="relative w-full md:w-72">
                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                    <input
                      type="text"
                      placeholder="Search name, email, or wallet..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full rounded-xl bg-slate-900/60 border border-slate-800 pl-10 pr-4 py-2 text-xs focus:outline-none focus:border-cyan-500 transition-all text-white"
                    />
                  </div>
                </div>

                {loading ? (
                  <div className="flex justify-center py-12">
                    <div className="h-8 w-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
                  </div>
                ) : filteredUsers.length === 0 ? (
                  <div className="py-16 text-center text-slate-500 space-y-2 bg-slate-900/20 rounded-2xl border border-slate-900">
                    <Users className="h-10 w-10 text-slate-700 mx-auto" />
                    <p className="font-bold text-slate-400 text-sm">{users.length === 0 ? 'No users registered yet.' : 'No users match your search.'}</p>
                    {users.length === 0 && (
                      <p className="text-xs max-w-md mx-auto text-slate-600">Registered accounts will appear here as real users sign up.</p>
                    )}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-slate-900 text-slate-500 uppercase tracking-wider text-[10px] font-semibold">
                          <th className="pb-3 pl-2">Name / Email</th>
                          <th className="pb-3">Subscription</th>
                          <th className="pb-3">Usage telemetry</th>
                          <th className="pb-3">Polygon Wallet</th>
                          <th className="pb-3 pr-2 text-right">Settings</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900">
                        {filteredUsers.map((u) => (
                          <tr key={u.id} className="hover:bg-slate-900/30 transition-colors">
                            <td className="py-3 pl-2">
                              <div>
                                <span className="font-semibold block text-slate-200">{u.name}</span>
                                <span className="text-slate-500 font-mono text-[11px] block">{u.email}</span>
                              </div>
                            </td>
                            <td className="py-3">
                              <span className={`px-2 py-0.5 rounded font-mono font-bold text-[10px] capitalize ${u.subscriptionTier === 'enterprise' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' : u.subscriptionTier === 'business' ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20' : u.subscriptionTier === 'pro' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'bg-slate-800 text-slate-400 border border-slate-700/50'}`}>
                                {u.subscriptionTier}
                              </span>
                            </td>
                            <td className="py-3 font-mono">
                              <span className="font-semibold text-slate-300">{u.usageCount}</span>
                              <span className="text-slate-600"> / {u.maxUsage === 999999999 ? '∞' : u.maxUsage}</span>
                            </td>
                            <td className="py-3">
                              {u.walletAddress ? (
                                <span className="font-mono text-cyan-500 font-semibold cursor-help" title={u.walletAddress}>
                                  {u.walletAddress.substring(0, 6)}...{u.walletAddress.substring(38)}
                                </span>
                              ) : (
                                <span className="text-slate-600 font-light font-sans text-[11px]">Unlinked</span>
                              )}
                            </td>
                            <td className="py-3 text-right pr-2">
                              <button
                                onClick={() => setSelectedUser(u)}
                                className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-[10px] font-bold text-slate-300"
                              >
                                Manage Profile
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* Selected User Management Overlay/Modal */}
            {selectedUser && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={() => setSelectedUser(null)} />
                <div className="relative w-full max-w-md rounded-2xl glass-panel-heavy p-6 border border-slate-900 text-white shadow-2xl">
                  <h3 className="font-display font-bold text-lg mb-4 text-gradient">Manage user profile: {selectedUser.name}</h3>
                  
                  <div className="space-y-4 text-xs">
                    <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 font-mono">
                      <p><span className="text-slate-500">EMAIL:</span> {selectedUser.email}</p>
                      <p><span className="text-slate-500">WALLED ADDRESS:</span> {selectedUser.walletAddress || 'None linked'}</p>
                      <p><span className="text-slate-500">VERIFIED STATUS:</span> {selectedUser.isVerified ? 'VERIFIED' : 'PENDING'}</p>
                      <p><span className="text-slate-500">CREATION RECORD:</span> {selectedUser.createdAt}</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Override Subscription tier</label>
                      <div className="grid grid-cols-4 gap-2">
                        {(['free', 'pro', 'business', 'enterprise'] as SubscriptionTier[]).map((tier) => (
                          <button
                            key={tier}
                            onClick={() => handleUpdateTier(selectedUser.id, tier)}
                            className={`py-1.5 rounded font-mono font-semibold capitalize border text-[11px] ${selectedUser.subscriptionTier === tier ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30' : 'bg-slate-900/40 border-slate-800 hover:bg-slate-800 text-slate-400'}`}
                          >
                            {tier}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="flex justify-between items-center py-2.5 border-t border-slate-900 mt-2">
                      <div className="space-y-0.5">
                        <span className="font-semibold text-slate-300 block">Administrative Privileges</span>
                        <span className="text-[10px] text-slate-500 block">Allows access to this secure management console.</span>
                      </div>
                      <button
                        onClick={() => handleToggleAdmin(selectedUser.id, !!selectedUser.isAdmin)}
                        className={`px-3 py-1.5 rounded-xl font-bold text-[11px] border transition-all ${selectedUser.isAdmin ? 'bg-purple-500/10 text-purple-400 border-purple-500/20 hover:bg-purple-500/20' : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'}`}
                      >
                        {selectedUser.isAdmin ? 'Revoke Admin' : 'Grant Admin'}
                      </button>
                    </div>

                    <button
                      onClick={() => setSelectedUser(null)}
                      className="w-full mt-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white transition-all"
                    >
                      Close Control Card
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: BILLING */}
            {activeTab === 'subscriptions' && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-display font-bold text-lg">Subscriptions & Payments Gateway</h3>
                  <p className="text-xs text-slate-500">Review Stripe subscription profiles and configure Web3 SCUT Token Polygon paywalls.</p>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 space-y-4">
                    <span className="text-[10px] text-cyan-400 font-bold tracking-widest block uppercase">Subscription Tiers (live from Firestore)</span>
                    <div className="space-y-2.5 text-xs">
                      {(['pro', 'business', 'enterprise'] as SubscriptionTier[]).map(tier => (
                        <div key={tier} className="flex justify-between font-mono">
                          <span className="text-slate-500 capitalize">{tier} accounts:</span>
                          <span className="text-slate-300">{users.filter(u => u.subscriptionTier === tier).length}</span>
                        </div>
                      ))}
                      <div className="flex justify-between font-mono pt-2 border-t border-slate-800">
                        <span className="text-slate-500">Payment processor:</span>
                        <span className="text-amber-400 font-semibold">Not yet connected</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 space-y-4">
                    <span className="text-[10px] text-amber-400 font-bold tracking-widest block uppercase">POLYGON WEB3 PAYMENTS</span>
                    <div className="space-y-2.5 text-xs">
                      <div className="flex justify-between font-mono">
                        <span className="text-slate-500">SCUT Token Contract:</span>
                        <span className="text-amber-400 font-semibold truncate">{SCUT_TOKEN_ADDRESS.substring(0, 6)}...{SCUT_TOKEN_ADDRESS.slice(-4)}</span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-slate-500">SCUT Token Standard:</span>
                        <span className="text-slate-300">ERC-20 (Polygon)</span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-slate-500">Wallet-linked accounts:</span>
                        <span className="text-slate-300">{users.filter(u => !!u.walletAddress).length}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Real billing history — no ledger connected yet, so honestly empty until one is wired up */}
                <div className="space-y-3">
                  <span className="text-[10px] text-slate-500 font-semibold block uppercase tracking-wider">Historical Transactions Record</span>
                  <div className="py-10 text-center text-slate-500 space-y-2 bg-slate-900/20 rounded-2xl border border-slate-900">
                    <CreditCard className="h-8 w-8 text-slate-700 mx-auto" />
                    <p className="font-bold text-slate-400 text-xs">No billing transactions yet</p>
                    <p className="text-[11px] max-w-md mx-auto text-slate-600">
                      This platform doesn't have a payment processor connected yet. Once one is wired up, real subscription and Web3 payment records will appear here.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: TICKETS */}
            {activeTab === 'tickets' && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-display font-bold text-lg">Support Queue SLA Control</h3>
                  <p className="text-xs text-slate-500">Inbound complaints, query feedback, and developer reports sent to: <span className="font-semibold text-cyan-400">gabrielicloudi@icloud.com</span>.</p>
                </div>

                {tickets.length === 0 ? (
                  <div className="py-12 text-center text-slate-500 space-y-2">
                    <CheckCircle className="h-10 w-10 text-emerald-500 mx-auto" />
                    <p className="font-bold">Queue Empty</p>
                    <p className="text-xs">No active unresolved help tickets or admin signals in index.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {tickets.map((t) => (
                      <div key={t.id} className="p-5 rounded-2xl bg-slate-900/40 border border-slate-900 flex justify-between items-start gap-4">
                        <div className="space-y-2 text-xs">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-slate-200">{t.name}</span>
                            <span className="text-slate-500 font-mono">({t.email})</span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase bg-purple-500/10 border border-purple-500/20 text-purple-400">
                              {t.category}
                            </span>
                          </div>
                          <p className="text-slate-300 leading-relaxed max-w-2xl font-light bg-slate-950/40 p-3 rounded-xl border border-slate-900/60 font-mono">
                            {t.message}
                          </p>
                          <span className="text-[10px] text-slate-500 block font-mono">Dispatched: {t.createdAt}</span>
                        </div>
                        <button
                          onClick={() => handleDeleteTicket(t.id)}
                          className="p-2 rounded-xl bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-400 hover:text-red-300 transition-all shrink-0"
                          title="Resolve & purge"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB: ANALYTICS */}
            {activeTab === 'analytics' && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-display font-bold text-lg">Ecosystem Realtime Telemetry</h3>
                  <p className="text-xs text-slate-500">Live operational usage, average token weights, system speed, and Gemini endpoint audits.</p>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 space-y-2">
                    <span className="text-slate-500 font-bold uppercase text-[9px] block">Total Registered Users</span>
                    <span className="text-2xl font-bold font-mono text-cyan-400">{users.length}</span>
                    <span className="text-[10px] text-slate-500 block">From Firestore users collection</span>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 space-y-2">
                    <span className="text-slate-500 font-bold uppercase text-[9px] block">Total Recorded Usage</span>
                    <span className="text-2xl font-bold font-mono text-teal-400">{users.reduce((sum, u) => sum + (typeof u.usageCount === 'number' ? u.usageCount : 0), 0).toLocaleString()}</span>
                    <span className="text-[10px] text-slate-500 block">Sum of per-account usageCount</span>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 space-y-2">
                    <span className="text-slate-500 font-bold uppercase text-[9px] block">Pending Approvals</span>
                    <span className="text-2xl font-bold font-mono text-purple-400">{users.filter(u => u.approvalStatus === 'pending_approval').length}</span>
                    <span className="text-[10px] text-slate-500 block">Awaiting review</span>
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-slate-900/30 border border-slate-900 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-300">SCUT Ecosystem Status</span>
                  </div>
                  <div className="space-y-2.5 text-xs font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Firebase Firestore connectivity:</span>
                      <span className={`font-semibold ${loading ? 'text-amber-400' : 'text-emerald-400'}`}>{loading ? 'Syncing…' : 'Connected'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Polygon RPC connectivity:</span>
                      <span className={`font-semibold ${chainDataError ? 'text-rose-400' : polygonGasPrice ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {chainDataError ? 'Unreachable' : polygonGasPrice ? 'Connected' : 'Checking…'}
                      </span>
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-600 pt-1">
                    Request latency and per-query telemetry aren't collected yet — that needs a server-side metrics/logging integration, which isn't wired up in this deployment.
                  </p>
                </div>
              </div>
            )}

            {/* TAB: WALLETS */}
            {activeTab === 'wallets' && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-display font-bold text-lg">Polygon SCUT Smart Contracts</h3>
                  <p className="text-xs text-slate-500">Monitor blockchain wallets and pre-authorization token mappings linked to accounts.</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 space-y-4">
                  <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                    <div className="space-y-0.5">
                      <span className="font-bold text-slate-200 block text-sm">POLYGON MAINNET INTEGRATION RULES</span>
                      <span className="text-[10px] text-slate-500 block">Official ecosystem contract specs for Web3 authorization</span>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 font-mono uppercase">
                      POLYGON BLOCKCHAIN
                    </span>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 text-xs font-mono">
                    <div className="space-y-2.5">
                      <p><span className="text-slate-500">Token Ticker:</span> <span className="font-bold text-slate-300">SCUT</span></p>
                      <p><span className="text-slate-500">Network ID:</span> <span className="text-slate-300">137 (Polygon POS)</span></p>
                      <p><span className="text-slate-500">Live gas price:</span> <span className="text-emerald-400 font-semibold">{chainDataError ? 'Unavailable' : polygonGasPrice || (chainDataLoading ? 'Loading…' : '—')}</span></p>
                    </div>
                    <div className="space-y-2.5">
                      <p><span className="text-slate-500">Treasury Wallet Balance:</span> <span className="text-slate-300">{chainDataError ? 'Unavailable' : treasuryBalance || (chainDataLoading ? 'Loading…' : '—')}</span></p>
                      <p><span className="text-slate-500">Treasury Address:</span> <span className="text-slate-400" title={DEFAULT_MERCHANT_ADDRESS}>{DEFAULT_MERCHANT_ADDRESS.substring(0, 6)}...{DEFAULT_MERCHANT_ADDRESS.slice(-4)}</span></p>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/20 border border-slate-900 space-y-3">
                  <span className="text-[10px] text-slate-500 font-semibold block uppercase tracking-wider">On-Chain Data</span>
                  <div className="flex gap-2 flex-wrap items-center">
                    <button
                      onClick={refreshChainData}
                      disabled={chainDataLoading}
                      className="px-3 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/25 text-[11px] font-bold text-cyan-400 disabled:opacity-50 flex items-center gap-1.5"
                    >
                      <RefreshCw className={`h-3 w-3 ${chainDataLoading ? 'animate-spin' : ''}`} />
                      Refresh from Polygon RPC
                    </button>
                    {chainDataError && (
                      <span className="text-[11px] text-rose-400">Couldn't reach the Polygon RPC endpoint. Try again.</span>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* TAB: SECURITY */}
            {activeTab === 'security' && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-display font-bold text-lg">Telemetry Security Audits</h3>
                  <p className="text-xs text-slate-500">Cryptographic hashes, session logs, and administrator security logs.</p>
                </div>

                <div className="space-y-3">
                  <span className="text-[10px] text-slate-500 font-semibold block uppercase tracking-wider">Admin Action Audit Trail (this session)</span>
                  {systemAlerts.length === 0 ? (
                    <div className="p-6 rounded-xl bg-slate-900/40 border border-slate-800 text-center text-slate-500 text-xs">
                      No administrator actions recorded yet this session.
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 space-y-2.5 font-mono text-[11px] text-slate-400 max-h-80 overflow-y-auto">
                      {systemAlerts.map((al, idx) => (
                        <p key={idx} className="text-slate-500">— {al}</p>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB: CREDITS (SCUT Virtual Currency Administrator) */}
            {activeTab === 'credits' && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-display font-bold text-lg">SCUT Credits (SVC) Ledger Authority</h3>
                  <p className="text-xs text-slate-500">Distribute platform rewards, audit virtual currency transactions, and adjust user reward balances.</p>
                </div>

                <div className="grid md:grid-cols-12 gap-6">
                  {/* Left part: User list with balances */}
                  <div className="md:col-span-7 space-y-4">
                    <div className="flex justify-between items-center bg-slate-900/40 p-3 rounded-xl border border-slate-850">
                      <span className="text-xs text-slate-300 font-mono">System Directory Users: {filteredUsers.length}</span>
                    </div>

                    <div className="space-y-2.5 max-h-[400px] overflow-y-auto pr-1">
                      {filteredUsers.length === 0 && (
                        <div className="py-10 text-center text-slate-600 text-xs">No users registered yet.</div>
                      )}
                      {filteredUsers.map((u) => {
                        const userBal = u.scutCredits !== undefined ? u.scutCredits : 100;
                        const isSelected = selectedUser && selectedUser.id === u.id;
                        return (
                          <div 
                            key={u.id}
                            onClick={() => setSelectedUser(u)}
                            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex justify-between items-center ${
                              isSelected 
                                ? 'bg-cyan-500/10 border-cyan-500/40' 
                                : 'bg-slate-900/20 border-slate-900 hover:border-slate-800'
                            }`}
                          >
                            <div className="min-w-0">
                              <span className="text-xs font-bold text-slate-200 block truncate">{u.name || 'Anonymous User'}</span>
                              <span className="text-[10px] text-slate-500 block truncate font-mono">{u.email}</span>
                            </div>
                            <div className="text-right shrink-0">
                              <span className="text-sm font-mono font-bold text-cyan-400 block">{userBal} SVC</span>
                              <span className="text-[9px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400 uppercase font-mono">{u.subscriptionTier || 'free'}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Right part: Adjustment controls */}
                  <div className="md:col-span-5 bg-slate-900/40 border border-slate-900 rounded-2xl p-5 space-y-4">
                    {selectedUser ? (
                      <AdminCreditForm 
                        user={selectedUser} 
                        onSuccess={async () => {
                          await refreshData();
                          // Set user balance selected user
                          const updatedUsers = await getAllUsers();
                          const reSelected = updatedUsers.find(u => u.id === selectedUser.id);
                          if (reSelected) {
                            setSelectedUser(reSelected);
                          }
                          setSystemAlerts(prev => [`Distributed SVC adjustments to database for: ${selectedUser.email}`, ...prev]);
                        }}
                      />
                    ) : (
                      <div className="text-center py-16 flex flex-col items-center justify-center space-y-3">
                        <Coins className="h-10 w-10 text-slate-700 animate-pulse" />
                        <div>
                          <h4 className="text-xs font-bold text-slate-400">No Profile Selected</h4>
                          <p className="text-[10px] text-slate-600 mt-0.5">Select a user profile from the ledger list to award or deduct credits.</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>

      </div>

      {/* Rejection Modal */}
      {rejectModalUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 max-w-md w-full space-y-4 text-left shadow-2xl">
            <h4 className="font-bold text-lg text-rose-400 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Reject Membership Application
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              You are rejecting <span className="font-semibold text-white">{rejectModalUser.name}</span> ({rejectModalUser.email}).
              An automated rejection email will be sent explaining the reason.
            </p>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 block">Rejection Reason / Note:</label>
              <textarea
                value={rejectionReasonInput}
                onChange={(e) => setRejectionReasonInput(e.target.value)}
                placeholder="e.g. Profile details incomplete or eligibility criteria not met..."
                rows={3}
                className="w-full rounded-xl bg-slate-900 border border-slate-800 p-3 text-xs focus:outline-none focus:border-rose-500 text-white"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  setRejectModalUser(null);
                  setRejectionReasonInput('');
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:bg-slate-900"
              >
                Cancel
              </button>
              <button
                onClick={handleRejectUser}
                disabled={actionProcessing}
                className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-400 text-white font-bold text-xs transition-all shadow-lg shadow-rose-500/20"
              >
                Confirm Rejection & Notify
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

interface AdminCreditFormProps {
  user: any;
  onSuccess: () => void;
}

function AdminCreditForm({ user, onSuccess }: AdminCreditFormProps) {
  const [amount, setAmount] = useState<number>(50);
  const [adjustmentType, setAdjustmentType] = useState<'earn_community' | 'earn_achievement' | 'earn_referral' | 'spend_ai' | 'spend_marketplace'>('earn_community');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      alert("Please enter a clear audit trail description.");
      return;
    }
    setLoading(true);
    setSuccessMsg(null);
    try {
      const isDeduction = adjustmentType.startsWith('spend');
      const finalAmount = isDeduction ? -Math.abs(amount) : Math.abs(amount);

      await adjustCredits(user.id, finalAmount, adjustmentType, description);
      setSuccessMsg(`Successfully logged ${finalAmount > 0 ? '+' : ''}${finalAmount} SVC to account ledger.`);
      setDescription('');
      onSuccess();
    } catch (err: any) {
      alert("Adjust Error: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <span className="text-[9px] text-slate-500 uppercase font-mono tracking-wider block">Currently Managing Ledger for:</span>
        <h4 className="text-sm font-bold text-slate-100 mt-0.5">{user.name || 'Anonymous User'}</h4>
        <p className="text-[10px] font-mono text-cyan-400 mt-0.5 truncate">{user.email}</p>
      </div>

      <div className="border-t border-slate-800/80 my-3" />

      {successMsg && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-[10px] text-emerald-400 font-semibold leading-normal">
          {successMsg}
        </div>
      )}

      <div className="space-y-3">
        <div>
          <label className="text-[10px] text-slate-500 uppercase font-mono tracking-wider block mb-1">Adjustment Action</label>
          <select
            value={adjustmentType}
            onChange={(e: any) => setAdjustmentType(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/40 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none"
          >
            <option value="earn_community">Ecosystem Award (+)</option>
            <option value="earn_achievement">Milestone Boost (+)</option>
            <option value="earn_referral">Referral Bonus (+)</option>
            <option value="spend_ai">Fine / Manual Charge (-)</option>
            <option value="spend_marketplace">Refund Settlement (+)</option>
          </select>
        </div>

        <div>
          <label className="text-[10px] text-slate-500 uppercase font-mono tracking-wider block mb-1">SCUT Credits Amount (SVC)</label>
          <input
            type="number"
            min="1"
            max="10000"
            value={amount}
            onChange={(e) => setAmount(parseInt(e.target.value) || 0)}
            className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/40 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
            required
          />
        </div>

        <div>
          <label className="text-[10px] text-slate-500 uppercase font-mono tracking-wider block mb-1">Audit Reason / Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g. Developer grant for community beta testing program..."
            rows={3}
            className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/40 rounded-xl px-3 py-2 text-xs text-white focus:outline-none placeholder-slate-600 resize-none"
            required
          />
        </div>
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-indigo-500 hover:from-cyan-400 hover:to-indigo-400 text-slate-950 font-extrabold text-xs rounded-xl transition-all shadow-lg shadow-cyan-500/10 cursor-pointer"
      >
        {loading ? 'Sinking ledger packet...' : 'Commit Transfer to Ledger'}
      </button>
    </form>
  );
}
