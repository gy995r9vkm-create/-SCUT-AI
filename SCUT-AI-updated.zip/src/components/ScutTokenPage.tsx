import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Coins, TrendingUp, Layers, Lock, Vote, Copy, ExternalLink, Wallet, DollarSign, 
  Check, Award, Compass, BookOpen, Clock, AlertCircle, ChevronRight, BarChart2,
  RefreshCw, CheckCircle2, Info, FileText, ArrowRight, ArrowUpRight, Shield, X
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { 
  connectInjectedBrowserWallet, connectWalletConnectModal,
  sendScutTokenPayment, SCUT_TOKEN_ADDRESS, fetchScutTokenTotalSupply
} from '../lib/web3';

interface ScutTokenPageProps {
  user: any;
  onNavigate: (page: string) => void;
  onAddLog?: (action: string, details: string, type: 'chat' | 'billing' | 'api' | 'security') => void;
}

export default function ScutTokenPage({ user, onNavigate, onAddLog }: ScutTokenPageProps) {
  // Wallet state — real balances only, no simulated starting values
  const [walletConnected, setWalletConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState('');
  const [scutBalance, setScutBalance] = useState(0);
  const [maticBalance, setMaticBalance] = useState(0);
  const [isConnecting, setIsConnecting] = useState(false);
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [totalSupply, setTotalSupply] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const [isCopied, setIsCopied] = useState(false);

  const contractAddress = SCUT_TOKEN_ADDRESS;

  // Real on-chain total supply
  useEffect(() => {
    fetchScutTokenTotalSupply().then(setTotalSupply).catch((err) => {
      console.warn('Could not fetch SCUT total supply:', err);
    });
  }, []);

  const handleCopyContract = () => {
    navigator.clipboard.writeText(contractAddress);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
    if (onAddLog) {
      onAddLog('Token Interaction', 'Copied token contract address to clipboard', 'security');
    }
  };

  const connectWallet = async (type: 'injected' | 'walletconnect' = 'injected') => {
    setIsConnecting(true);
    try {
      const walletState = type === 'injected'
        ? await connectInjectedBrowserWallet()
        : await connectWalletConnectModal();
      
      setWalletAddress(`${walletState.address.substring(0, 6)}...${walletState.address.substring(walletState.address.length - 4)}`);
      setScutBalance(parseFloat(walletState.scutBalance) || 0);
      setMaticBalance(parseFloat(walletState.polBalance) || 0);
      setWalletConnected(true);
      setShowWalletModal(false);

      if (onAddLog) {
        onAddLog('Web3 Connection', `Successfully connected wallet ${walletState.address} via ${walletState.providerType} on Polygon`, 'security');
      }
      showNotification(`Connected ${walletState.providerType === 'injected' ? 'MetaMask / Extension' : 'WalletConnect'} on Polygon!`);
    } catch (err: any) {
      console.error(err);
      showNotification(err.message || 'Failed to connect Web3 Wallet');
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12 px-4 sm:px-6 lg:px-8 space-y-12">
      {/* HERO SECTION */}
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8 border-b border-slate-900 pb-12">
        <div className="space-y-4 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/25 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
            <Coins className="h-3.5 w-3.5 animate-pulse" />
            Official Polygon Token
          </div>
          <h1 className="text-3xl sm:text-5xl font-display font-extrabold tracking-tight text-white">
            The Governance & Utility Token of <span className="text-cyan-400">SCUT</span> Ecosystem
          </h1>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            One native cryptographically secured asset running directly on the Polygon blockchain. 
            SCUT powers payments via SCUT Pay, unlocks business portal discounts, offers DAO voting rights, 
            and fuels Mica Bucurie’s premium artisanal digital commerce loops.
          </p>

          {/* Contract Address copy box */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 w-full max-w-md">
              <span className="text-[10px] font-mono uppercase tracking-widest text-slate-500">Contract</span>
              <span className="text-xs font-mono text-slate-300 select-all overflow-hidden text-ellipsis whitespace-nowrap">{contractAddress}</span>
              <button 
                onClick={handleCopyContract}
                className="ml-auto p-1.5 rounded bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
                title="Copy to clipboard"
              >
                {isCopied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>

            <a 
              href={`https://polygonscan.com/token/${contractAddress}`}
              target="_blank"
              rel="noopener noreferrer"
              referrerPolicy="no-referrer"
              className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-200 hover:text-white flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <ExternalLink className="h-4 w-4" />
              Polygonscan
            </a>
          </div>
        </div>

        {/* Live Token Status Widget / Wallet connector */}
        <div className="w-full max-w-sm bg-slate-900/60 border border-slate-850 rounded-2xl p-6 shadow-xl space-y-6 relative overflow-hidden backdrop-blur-sm">
          <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full filter blur-2xl" />
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                <Coins className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-xs text-slate-400 font-bold uppercase tracking-wider">Ecosystem Asset</h4>
                <p className="text-sm font-extrabold text-white">SCUT Token</p>
              </div>
            </div>
            
            {walletConnected ? (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                {walletAddress}
              </div>
            ) : (
              <button
                onClick={() => setShowWalletModal(true)}
                className="px-3 py-1.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Wallet className="h-3.5 w-3.5" />
                Connect Wallet
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="bg-slate-950/65 rounded-xl p-3 border border-slate-850">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">SCUT Balance</span>
              <p className="text-base font-extrabold text-white mt-1">
                {walletConnected ? scutBalance.toLocaleString() : '—'} <span className="text-xs text-cyan-400 font-medium">SCUT</span>
              </p>
            </div>
            <div className="bg-slate-950/65 rounded-xl p-3 border border-slate-850">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Gas (MATIC)</span>
              <p className="text-base font-extrabold text-white mt-1">
                {walletConnected ? maticBalance.toFixed(2) : '—'} <span className="text-xs text-slate-400 font-medium">MATIC</span>
              </p>
            </div>
          </div>

          <div className="border-t border-slate-850 pt-4 space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Total Supply</span>
              <span className="text-slate-200 font-mono font-bold">{totalSupply ? `${totalSupply} SCUT` : 'Loading…'}</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Network</span>
              <span className="text-slate-200 font-mono font-bold">Polygon Mainnet</span>
            </div>
          </div>
        </div>
      </div>

      {/* CHARTS & ANALYTICS GRIDS */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart Card */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-850 rounded-2xl p-6 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Market Price</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-lg font-bold text-slate-400">Not available yet</span>
              </div>
            </div>
          </div>

          <div className="h-64 w-full flex flex-col items-center justify-center text-center gap-2 border border-dashed border-slate-800 rounded-xl">
            <BarChart2 className="h-8 w-8 text-slate-700" />
            <p className="text-xs font-bold text-slate-400">No live price feed connected</p>
            <p className="text-[11px] text-slate-600 max-w-sm px-4">
              SCUT isn't listed on a DEX/price oracle yet, so there's no real price history to chart. This will populate automatically once one is connected.
            </p>
          </div>
        </div>

        {/* Side Key Metrics Panel */}
        <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <BarChart2 className="h-4 w-4 text-cyan-400" />
                Token Metrics
              </h3>
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Polygon Core</span>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Total Supply</span>
                  <p className="text-sm font-extrabold text-white font-mono mt-1">{totalSupply ? `${totalSupply} SCUT` : 'Loading…'}</p>
                </div>
                <div className="h-8 w-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <TrendingUp className="h-4 w-4" />
                </div>
              </div>

              <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Standard</span>
                  <p className="text-sm font-extrabold text-white font-mono mt-1">ERC-20</p>
                </div>
                <div className="h-8 w-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
                  <Layers className="h-4 w-4" />
                </div>
              </div>

              <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Market Cap / Volume</span>
                  <p className="text-xs font-bold text-slate-500 mt-1">Not tracked — no DEX listing yet</p>
                </div>
                <div className="h-8 w-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center">
                  <DollarSign className="h-4 w-4" />
                </div>
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-cyan-500/5 border border-cyan-500/10 text-slate-400 text-xs leading-relaxed flex gap-2.5">
            <Info className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
            <span>
              SCUT token contract is officially deployed on the Polygon Mainnet. Avoid spoof or copycat tokens with similar names. Always verify contract address matches official channels.
            </span>
          </div>
        </div>
      </div>

      {/* STAKING & COMMUNITY GOVERNANCE ROW */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Staking Center */}
        <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 space-y-6">
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lock className="h-4 w-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white">SCUT Staking Pool</h3>
            </div>
          </div>

          <div className="py-10 text-center space-y-2">
            <Lock className="h-8 w-8 text-slate-700 mx-auto" />
            <p className="text-xs font-bold text-slate-400">Staking isn't live yet</p>
            <p className="text-[11px] text-slate-600 max-w-sm mx-auto">
              There's no staking contract deployed for SCUT yet. Once one is, real locked positions and real on-chain rewards will show up here.
            </p>
          </div>
        </div>

        {/* DAO Governance Proposals */}
        <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 space-y-6">
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Vote className="h-4 w-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white">DAO Ecosystem Governance</h3>
            </div>
          </div>

          <div className="py-10 text-center space-y-2">
            <Vote className="h-8 w-8 text-slate-700 mx-auto" />
            <p className="text-xs font-bold text-slate-400">Governance voting isn't live yet</p>
            <p className="text-[11px] text-slate-600 max-w-sm mx-auto">
              There's no on-chain governance contract connected yet, so there are no real proposals to vote on. This will populate once one is deployed.
            </p>
          </div>
        </div>
      </div>

      {/* ROADMAP & UTILITY GRID */}
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="border-b border-slate-900 pb-3 flex items-center gap-2">
          <Compass className="h-5 w-5 text-cyan-400" />
          <h3 className="text-lg font-display font-bold text-white">Ecosystem Roadmap & Utility Matrix</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-slate-900 border border-slate-850 p-5 rounded-2xl space-y-3">
            <div className="h-10 w-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Award className="h-5 w-5" />
            </div>
            <h4 className="text-sm font-bold text-white">Phase 1: SCUT AI Launch</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Establishing our proprietary multimodal workspace integrated with Web Search, Document Parsing, Voice processing, and premium localized AI streaming.
            </p>
            <span className="inline-block text-[9px] font-mono font-bold text-emerald-400 uppercase tracking-wider">Completed</span>
          </div>

          <div className="bg-slate-900 border border-slate-850 p-5 rounded-2xl space-y-3">
            <div className="h-10 w-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Lock className="h-5 w-5" />
            </div>
            <h4 className="text-sm font-bold text-white">Phase 2: SCUT Pay & Token Staking</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Unifying digital commerce with Polygon smart contracts, decentralized payment invoices, community staker APY models, and real-time ledger auditing.
            </p>
            <span className="inline-block text-[9px] font-mono font-bold text-cyan-400 uppercase tracking-wider">In Progress</span>
          </div>

          <div className="bg-slate-900 border border-slate-850 p-5 rounded-2xl space-y-3">
            <div className="h-10 w-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Layers className="h-5 w-5" />
            </div>
            <h4 className="text-sm font-bold text-white">Phase 3: Artisanal Marketplace</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Developing Mica Bucurie’s premium local commerce marketplace and business portal, bringing hundreds of artisanal vendors onto the blockchain ecosystem.
            </p>
            <span className="inline-block text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Scheduled Q4 2026</span>
          </div>

          <div className="bg-slate-900 border border-slate-850 p-5 rounded-2xl space-y-3">
            <div className="h-10 w-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Shield className="h-5 w-5" />
            </div>
            <h4 className="text-sm font-bold text-white">Phase 4: Multi-Chain Governance</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Transitioning to full multi-chain DAO governance models, zero-knowledge payment receipts, localized compliance auditing, and secure enterprise REST APIs.
            </p>
            <span className="inline-block text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Scheduled 2027</span>
          </div>
        </div>
      </div>

      {/* WEB3 WALLET CONNECT MODAL */}
      <AnimatePresence>
        {showWalletModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 space-y-6 text-slate-100"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Wallet className="h-5 w-5 text-cyan-400" />
                  <h3 className="text-base font-display font-semibold text-slate-100">Connect a Web3 Wallet</h3>
                </div>
                <button
                  onClick={() => setShowWalletModal(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                Choose your preferred Polygon network provider to interact with the SCUT Staking and Governance modules.
              </p>

              <div className="space-y-2">
                {[
                  { name: 'MetaMask / Browser Extension', icon: '🦊', type: 'injected' as const },
                  { name: 'WalletConnect Protocol', icon: '🔗', type: 'walletconnect' as const },
                  { name: 'Coinbase Wallet / Mobile', icon: '🔵', type: 'injected' as const }
                ].map((wallet) => (
                  <button
                    key={wallet.name}
                    onClick={() => connectWallet(wallet.type)}
                    disabled={isConnecting}
                    className="w-full p-3.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-850 hover:border-cyan-500/40 text-left transition-all cursor-pointer flex items-center justify-between group disabled:opacity-55"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-xl">{wallet.icon}</span>
                      <span className="text-xs font-bold text-slate-200 group-hover:text-white">{wallet.name}</span>
                    </div>
                    <ChevronRight className="h-4 w-4 text-slate-500 group-hover:text-cyan-400 transition-colors" />
                  </button>
                ))}
              </div>

              {isConnecting && (
                <div className="flex items-center justify-center gap-2 text-xs text-cyan-400 font-semibold animate-pulse py-2">
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Awaiting wallet signature...
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Custom Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-cyan-500/30 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-2 animate-bounce">
          <Shield className="h-4 w-4 text-cyan-400 shrink-0" />
          <span className="text-xs font-semibold tracking-wide">{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
